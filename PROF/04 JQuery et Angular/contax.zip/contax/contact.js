var contacts = [
  {
    nom:'Tentou',
    prenom:'Jean',
    num:'02-02-45-87-58',
    imag:'jean.jpeg'
  },
  {
    nom:'Sihon',
    prenom:'Rémi',
    num :'03-02-45-87-88',
    imag:'remi.jpeg'
  },
  {
    nom:'Plusfor',
    prenom:'Amélie',
    num:'06-04-85-88-71',
    imag:'amelie.jpeg'
  },
  {
    nom:'Dondecourse',
    prenom:'Guy',
    num:'07-58-87-00-54',
    imag:'guy.jpeg'
  },
  {
    nom:'Kiroul',
    prenom:'Pierre',
    num:'07-58-74-10-54',
    imag:'pierre.jpeg'
  },
  {
    nom:'Ankor',
    prenom:'Sylvie',
    num:'07-54-84-11-44',
    imag:'sylvie.jpeg'
  }
];
$(document).ready(function(){
  for (var i = 0; i < contacts.length; i++) {
    $("#contaxDiv").append("<div class='contact' id='contact"+i+"'></div>")
    $("#contact"+i).append("<img src="+contacts[i].imag+" id='im"+i+"'/>");
    $("#contact"+i).append("<div id='te"+i+"'>"+contacts[i].nom+"</BR>"+contacts[i].prenom+"</BR>"+contacts[i].num+"</BR></div>");
    $("#te"+i).hide();
  }

  $(".contact").hover(function(){
    $(this).children("img").hide();
    $(this).children("div").show();
  },
  function(){
    $(this).children("div").hide();
    $(this).children("img").show();
  });
});
