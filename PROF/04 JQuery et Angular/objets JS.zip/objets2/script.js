var voiture = {
  nom:"4L",
  marque:"Renault",
  rouler:function(){
    alert("Vroum la "+this.nom+" "+this.marque);
  }
}
voiture.rouler();

alert(voiture.nom);
alert(voiture["nom"]);

voiture.nbPorte=4;

alert(voiture.nbPorte + " portes");

voiture[0]="Le moteur fuit";
voiture[1]="Le bas de caisse est rouillé";

alert(voiture[0]);
