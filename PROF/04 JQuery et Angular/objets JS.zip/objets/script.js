// Déclaration d'un objet comme un constructeur
function Voiture(fabricant, modele, annee) {
  this.fabricant = fabricant;
  this.modele = modele;
  this.annee = annee;
  // Déclaration d'une méthode
  this.deplacement = function(){
  	alert("broommm");
  }
}

// instanciation
var maVoiture = new Voiture("Eagle", "Talon TSi", 1993);
maVoiture.deplacement();

// ajouit d'un attribut à la volée
maVoiture.nbPlace = 4;

// ajout d'une méthode à la volée
maVoiture.voler=function(){
	alert("je vole");
}
maVoiture.voler();

var monAutreVoiture = new Voiture("Citroen", "2Cv", 1973);
monAutreVoiture.deplacement();
//monAutreVoiture.voler(); // ici la méthode n'existe pas donc plantage
