$(function(){

	function Contact(nom, prenom, age, tel, image){
		this.nom = nom;
		this.prenom = prenom;
		this.age = age;
		this.tel = tel;
		this.image = image;
	}

	var contacts = []

	var contact1 = new Contact('Emploi', 'Paule', '44', '0011223344', 'image/icone_compte.png');
	var contact2 = new Contact('Time', 'Vincent', '22', '0011223344', 'image/icone_compte.png');
	var contact3 = new Contact('Ochon', 'Paul', '46', '0011223344', 'image/icone_compte.png');
	var contact4 = new Contact('Croche', 'Sarah', '33', '0011223344', 'image/icone_compte.png');
	var contact5 = new Contact('Térieur', 'Alain', '59', '0011223344', 'image/icone_compte.png');
	var contact6 = new Contact('Housse', 'Sandra', '41', '0011223344', 'image/icone_compte.png');
	var contact7 = new Contact('Térieur', 'Alex', '35', '0011223344', 'image/icone_compte.png');
	var contact8 = new Contact('Rive', 'Elsa', '21', '0011223344', 'image/icone_compte.png');
	var contact9 = new Contact('Arrivepas', 'Johnny', '39', '0011223344', 'image/icone_compte.png');

	contacts.push(contact1);
	contacts.push(contact2);
	contacts.push(contact3);
	contacts.push(contact4);
	contacts.push(contact5);
	contacts.push(contact6);
	contacts.push(contact7);
	contacts.push(contact8);
	contacts.push(contact9);

	// remplit le 'content' avec les contacts
	for(var i = 0; i < contacts.length; i ++){

		var str = '<div>' + contacts[i].prenom;
		str += '<br>';
		str += contacts[i].nom;
		str += '<br>';
		str += contacts[i].age + ' ans';
		str += '<br>';
		str += contacts[i].tel + '</div>';

		$('#content').append('<div class="' + i + '"><img src="' + contacts[i].image + '"></div>');
		$('.' + i).append(str);
		// cache les informations
		$('.' + i + ' div').hide();
	}

	$('#content div').hover(function(){
		// quand la souris entre sur un contact
		var i = $(this).attr('class');

		// cache l'image et montre les infos
		$('.' + i + ' img').hide();
		$('.' + i + ' div').show();

	}, function(){
		// quand la souris sort d'un contact
		var i = $(this).attr('class');

		// cache les infos et montre l'image
		$('.' + i + ' img').show();
		$('.' + i + ' div').hide();
	});

});